package mx.edu.ittepic.practicau1_5_profesiones_jonathanvizcarra;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Pantalla1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla1);
        getSupportActionBar().hide();
    }
    public void salir(View v){finish();}
    public void pantalla1(View v){setContentView(R.layout.activity_pantalla1);}
    public void pantalla2(View v){setContentView(R.layout.activity_pantalla2);}
    public void pantalla3(View v){setContentView(R.layout.activity_pantalla3);}
    public void pantalla4(View v){setContentView(R.layout.activity_pantalla4);}
    public void pantalla5(View v){setContentView(R.layout.activity_pantalla5);}
}
